package com.example.demo.repository;

import com.example.demo.entity.Employee;
import com.example.demo.projection.EmployeeDTO;
import com.example.demo.projection.EmployeeProjection;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;


public interface EmployeeRepository extends JpaRepository<Employee, Long> {

    List<Employee> findByDepartmentName(String departmentName);

    @Query("SELECT e FROM Employee e WHERE e.email LIKE %:domain")
    List<Employee> findByEmailDomain(@Param("domain") String domain);

    @Query(name = "Employee.findByName")
    List<Employee> findByName(@Param("name") String name);


    Page<Employee> findAll(Pageable pageable);


    @Query("SELECT e FROM Employee e WHERE e.name = :name")
    List<EmployeeProjection> findEmployeesByName(String name);

    @Query("SELECT new com.example.demo.projection.EmployeeDTO(e.name, e.email) FROM Employee e WHERE e.department.name = :departmentName")
    List<EmployeeDTO> findEmployeesByDepartmentName(String departmentName);



}