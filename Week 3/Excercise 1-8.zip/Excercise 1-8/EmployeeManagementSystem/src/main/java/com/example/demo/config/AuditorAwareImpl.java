package com.example.demo.config;

import org.springframework.data.domain.AuditorAware;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
public class AuditorAwareImpl implements AuditorAware<String> {

    @Override
    public Optional<String> getCurrentAuditor() {
        // Here, return the current user's username or ID
        // For example, you might get it from a security context or session
        return  Optional.of("admin"); // Replace this with logic to get the actual user
    }
}
