package EMPLOYEE_MANAGEMENT;

import java.util.Scanner;

public class EmployeeManagementSystem {
    private Employee[] employees;
    private int count;

    public EmployeeManagementSystem(int size) {
        employees = new Employee[size];
        count = 0;
    }

    
    public void addEmployee(Employee employee) {
        if (count < employees.length) {
            employees[count++] = employee;
        } else {
            System.out.println("No more space to add new employees.");
        }
    }

  
    public Employee searchEmployee(String employeeId) {
        for (Employee emp : employees) {
            if (emp != null && emp.getEmployeeId().equals(employeeId)) {
                return emp;
            }
        }
        return null;
    }


    public void traverseEmployees() {
        for (Employee emp : employees) {
            if (emp != null) {
                System.out.println(emp);
            }
        }
    }

    public void deleteEmployee(String employeeId) {
        for (int i = 0; i < count; i++) {
            if (employees[i] != null && employees[i].getEmployeeId().equals(employeeId)) {
                
                for (int j = i; j < count - 1; j++) {
                    employees[j] = employees[j + 1];
                }
                employees[--count] = null;
                System.out.println("Employee deleted.");
                return;
            }
        }
        System.out.println("Employee not found.");
    }

    public static void main(String[] args) {
        EmployeeManagementSystem system = new EmployeeManagementSystem(10);

        Scanner sc = new Scanner(System.in);
        while (true) {
            System.out.println("Choose an operation:");
            System.out.println("1. Add Employee");
            System.out.println("2. Search Employee");
            System.out.println("3. Traverse Employees");
            System.out.println("4. Delete Employee");
            System.out.println("5. Exit");
            int choice = sc.nextInt();
            sc.nextLine(); 

            switch (choice) {
                case 1:
                    System.out.println("Enter Employee ID, Name, Position, and Salary:");
                    String id = sc.nextLine();
                    String name = sc.nextLine();
                    String position = sc.nextLine();
                    double salary = sc.nextDouble();
                    system.addEmployee(new Employee(id, name, position, salary));
                    break;
                case 2:
                    System.out.println("Enter Employee ID to search:");
                    id = sc.nextLine();
                    Employee emp = system.searchEmployee(id);
                    if (emp != null) {
                        System.out.println("Employee found: " + emp);
                    } else {
                        System.out.println("Employee not found.");
                    }
                    break;
                case 3:
                    system.traverseEmployees();
                    break;
                case 4:
                    System.out.println("Enter Employee ID to delete:");
                    id = sc.nextLine();
                    system.deleteEmployee(id);
                    break;
                case 5:
                    sc.close();
                    System.exit(0);
            }
        }
    }
}
