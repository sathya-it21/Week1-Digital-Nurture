package TASK_MANAGEMENT;

class Node {
    Task task;
    Node next;

    public Node(Task task) {
        this.task = task;
        this.next = null;
    }
}

public class TaskLinkedList {
    private Node head;

    public TaskLinkedList() {
        this.head = null;
    }

    
    public void addTask(Task task) {
        Node newNode = new Node(task);
        if (head == null) {
            head = newNode;
        } else {
            Node current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode;
        }
    }

    
    public Task searchTask(String taskId) {
        Node current = head;
        while (current != null) {
            if (current.task.getTaskId().equals(taskId)) {
                return current.task;
            }
            current = current.next;
        }
        return null; 
    }

 
    public void traverseTasks() {
        Node current = head;
        while (current != null) {
            System.out.println(current.task);
            current = current.next;
        }
    }

    
    public void deleteTask(String taskId) {
        if (head == null) {
            return; 
        }

        if (head.task.getTaskId().equals(taskId)) {
            head = head.next;             return;
        }

        Node current = head;
        while (current.next != null && !current.next.task.getTaskId().equals(taskId)) {
            current = current.next;
        }

        if (current.next != null) {
            current.next = current.next.next;
        } else {
            System.out.println("Task not found");
        }
    }

    public static void main(String[] args) {
        TaskLinkedList taskList = new TaskLinkedList();

        taskList.addTask(new Task("1", "Task 1", "Incomplete"));
        taskList.addTask(new Task("2", "Task 2", "Incomplete"));
        taskList.addTask(new Task("3", "Task 3", "Complete"));

        System.out.println("Tasks in the list:");
        taskList.traverseTasks();

        System.out.println("Searching for Task with ID 2:");
        Task task = taskList.searchTask("2");
        System.out.println(task != null ? task : "Task not found");

        System.out.println("Deleting Task with ID 2:");
        taskList.deleteTask("2");

        System.out.println("Tasks in the list after deletion:");
        taskList.traverseTasks();
    }
}
