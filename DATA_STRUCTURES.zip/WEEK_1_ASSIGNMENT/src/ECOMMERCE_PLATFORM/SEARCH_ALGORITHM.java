package ECOMMERCE_PLATFORM;

import java.util.Arrays;
import java.util.Scanner;

public class SEARCH_ALGORITHM {


    public static int linearSearch(PRODUCT[] products, String searchId) {
        for (int i = 0; i < products.length; i++) {
            if (products[i].getProductId().equals(searchId)) {
                return i; 
            }
        }
        return -1; 
    }

    // Binary Search Algorithm
    public static int binarySearch(PRODUCT[] products, String searchId) {
        int left = 0;
        int right = products.length - 1;
        while (left <= right) {
            int mid = left + (right - left) / 2;
            if (products[mid].getProductId().compareTo(searchId) == 0) {
                return mid; // Return the index of the found product
            }
            if (products[mid].getProductId().compareTo(searchId) < 0) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return -1; // Product not found
    }

    public static void main(String[] args) {
        
        PRODUCT[] productsUnsorted = {
            new PRODUCT("003", "Smartphone", "Electronics"),
            new PRODUCT("002", "Laptop", "Electronics"),
            new PRODUCT("001", "Coffee Maker", "Home Appliances"),
            new PRODUCT("004", "Headphones", "Accessories")
        };

        PRODUCT[] productsSorted = Arrays.copyOf(productsUnsorted, productsUnsorted.length);
        Arrays.sort(productsSorted, (p1, p2) -> p1.getProductId().compareTo(p2.getProductId()));

        
        Scanner scanner = new Scanner(System.in);

        
        System.out.print("Enter the Product ID to search: ");
        String searchId = scanner.nextLine();

        
        int linearResult = linearSearch(productsUnsorted, searchId);
        if (linearResult != -1) {
            System.out.println("Linear Search: Product found at index " + linearResult);
        } else {
            System.out.println("Linear Search: Product not found");
        }

                int binaryResult = binarySearch(productsSorted, searchId);
        if (binaryResult != -1) {
            System.out.println("Binary Search: Product found at index " + binaryResult);
        } else {
            System.out.println("Binary Search: Product not found");
        }

                scanner.close();
    }
}
