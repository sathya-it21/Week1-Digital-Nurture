package INVENTORY_MANAGEMENT_SYSTEM;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Inventory {
    private Map<String, PRODUCT> inventory;

    public Inventory() {
        this.inventory = new HashMap<>();
    }

    public void addProduct(PRODUCT product) {
        inventory.put(product.getProductId(), product);
    }

    public void updateProduct(PRODUCT product) {
        if (inventory.containsKey(product.getProductId())) {
            inventory.put(product.getProductId(), product);
        } else {
            System.out.println("Product not found in inventory.");
        }
    }

    public void deleteProduct(String productId) {
        if (inventory.containsKey(productId)) {
            inventory.remove(productId);
        } else {
            System.out.println("Product not found in inventory.");
        }
    }

    public void displayInventory() {
        for (PRODUCT product : inventory.values()) {
            System.out.println(product);
        }
    }

    public static void main(String[] args) {
        Inventory manager = new Inventory();

        Scanner sc = new Scanner(System.in);
        while (true) {
            System.out.println("Choose an operation:");
            System.out.println("1. Add Product");
            System.out.println("2. Update Product");
            System.out.println("3. Delete Product");
            System.out.println("4. Display Inventory");
            System.out.println("5. Exit");
            int choice = sc.nextInt();

            switch (choice) {
                case 1:
                    System.out.println("Enter Product ID, Name, Quantity, and Price:");
                    String id = sc.next();
                    String name = sc.next();
                    int quantity = sc.nextInt();
                    double price = sc.nextDouble();
                    manager.addProduct(new PRODUCT(id, name, quantity, price));
                    break;
                case 2:
                    System.out.println("Enter Product ID, Name, Quantity, and Price:");
                    id = sc.next();
                    name = sc.next();
                    quantity = sc.nextInt();
                    price = sc.nextDouble();
                    manager.updateProduct(new PRODUCT(id, name, quantity, price));
                    break;
                case 3:
                    System.out.println("Enter Product ID to delete:");
                    id = sc.next();
                    manager.deleteProduct(id);
                    break;
                case 4:
                    manager.displayInventory();
                    break;
                case 5:
                    sc.close();
                    System.exit(0);
            }
        }
    }
}
