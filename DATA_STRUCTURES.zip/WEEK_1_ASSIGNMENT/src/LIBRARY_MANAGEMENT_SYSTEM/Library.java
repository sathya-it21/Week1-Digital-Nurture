package LIBRARY_MANAGEMENT_SYSTEM;

import java.util.Arrays;
import java.util.Scanner;

public class Library {
    private Book[] books;
    private int count;

    public Library(int capacity) {
        books = new Book[capacity];
        count = 0;
    }

    public void addBook(Book book) {
        if (count < books.length) {
            books[count++] = book;
        } else {
            System.out.println("Library is full. Cannot add more books.");
        }
    }

    public int linearSearchByTitle(String title) {
        for (int i = 0; i < count; i++) {
            if (books[i].getTitle().equalsIgnoreCase(title)) {
                return i;
            }
        }
        return -1;
    }

    public int binarySearchByTitle(String title) {
        Arrays.sort(books, 0, count, (b1, b2) -> b1.getTitle().compareToIgnoreCase(b2.getTitle()));
        int left = 0;
        int right = count - 1;
        while (left <= right) {
            int mid = left + (right - left) / 2;
            int compareResult = books[mid].getTitle().compareToIgnoreCase(title);
            if (compareResult == 0) {
                return mid;
            } else if (compareResult < 0) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return -1;
    }

    public void displayBook(int index) {
        if (index >= 0 && index < count) {
            System.out.println(books[index]);
        } else {
            System.out.println("Book not found.");
        }
    }

    public static void main(String[] args) {
        Library library = new Library(10);
        Scanner sc = new Scanner(System.in);

        // Adding sample books
        library.addBook(new Book("001", "To Kill a Mockingbird", "Harper Lee"));
        library.addBook(new Book("002", "1984", "George Orwell"));
        library.addBook(new Book("003", "The Great Gatsby", "F. Scott Fitzgerald"));
        library.addBook(new Book("004", "The Catcher in the Rye", "J.D. Salinger"));

        System.out.println("Enter the title of the book to search:");
        String title = sc.nextLine();

        // Linear Search
        int linearIndex = library.linearSearchByTitle(title);
        if (linearIndex != -1) {
            System.out.println("Linear Search: Book found at index " + linearIndex);
            library.displayBook(linearIndex);
        } else {
            System.out.println("Linear Search: Book not found.");
        }

        // Binary Search
        int binaryIndex = library.binarySearchByTitle(title);
        if (binaryIndex != -1) {
            System.out.println("Binary Search: Book found at index " + binaryIndex);
            library.displayBook(binaryIndex);
        } else {
            System.out.println("Binary Search: Book not found.");
        }

        sc.close();
    }
}
