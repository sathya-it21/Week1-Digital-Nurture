package com.library.repository;

public class BookRepository {
    // Example method
    public void printRepository() {
        System.out.println("BookRepository is working.");
    }
}
