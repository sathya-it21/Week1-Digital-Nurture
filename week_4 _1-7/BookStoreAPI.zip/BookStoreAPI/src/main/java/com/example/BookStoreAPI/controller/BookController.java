package com.example.BookStoreAPI.controller;

import com.example.BookStoreAPI.model.Book;
import com.example.BookStoreAPI.service.BookService;
import com.example.BookStoreAPI.exception.ResourceNotFoundException; // Import the custom exception
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/books")
public class BookController {

    private final BookService bookService;

    public BookController(BookService bookService) {
        this.bookService = bookService;
    }

    @GetMapping("/{id}")
    public ResponseEntity<Book> getBookById(@PathVariable("id") int id) {
        Optional<Book> book = bookService.getBookById(id);
        if (book.isPresent()) {
            return ResponseEntity.ok(book.get());
        } else {
            throw new ResourceNotFoundException("Book not found with ID: " + id);
        }
    }

    @PostMapping
    public ResponseEntity<String> addBook(@RequestBody Book book) {
        bookService.createBook(book);
        HttpHeaders headers = new HttpHeaders();
        headers.add("Location", "/books/" + book.getId());
        return ResponseEntity.status(HttpStatus.CREATED).headers(headers).body("Book successfully created.");
    }

    @PutMapping("/{id}")
    public ResponseEntity<String> updateBook(@PathVariable("id") int id, @RequestBody Book updatedBook) {
        Optional<Book> existingBook = bookService.getBookById(id);
        if (existingBook.isPresent()) {
            bookService.updateBook(id, updatedBook);
            HttpHeaders headers = new HttpHeaders();
            headers.add("Update-Info", "Book updated successfully");
            return ResponseEntity.ok().headers(headers).body("Book successfully updated.");
        } else {
            throw new ResourceNotFoundException("Book not found with ID: " + id);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteBook(@PathVariable("id") int id) {
        Optional<Book> book = bookService.getBookById(id);
        if (book.isPresent()) {
            bookService.deleteBook(id);
            return ResponseEntity.status(HttpStatus.NO_CONTENT).body("Book successfully deleted.");
        } else {
            throw new ResourceNotFoundException("Book not found with ID: " + id);
        }
    }

    @GetMapping
    public ResponseEntity<List<Book>> getAllBooks() {
        List<Book> books = bookService.getAllBooks();
        HttpHeaders headers = new HttpHeaders();
        headers.add("Total-Books", String.valueOf(books.size()));
        return ResponseEntity.ok().headers(headers).body(books);
    }
}
