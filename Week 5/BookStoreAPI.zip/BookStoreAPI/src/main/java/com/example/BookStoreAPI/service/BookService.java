package com.example.BookStoreAPI.service;

import com.example.BookStoreAPI.dto.BookDTO;
import com.example.BookStoreAPI.exception.ResourceNotFoundException;
import com.example.BookStoreAPI.model.Book;
import com.example.BookStoreAPI.repository.BookRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BookService {

    @Autowired
    private BookRepository bookRepository;

    public BookDTO getBook(Long id) {
        // Fetch the book entity from the repository
        Book book = (Book) bookRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Book not found with id " + id));

        // Convert the book entity to a DTO
        return new BookDTO(
                book.getId(),
                book.getTitle(),
                book.getAuthor(),
                book.getPublicationDate(),
                book.getPrice(),
                book.getIsbn()
        );
    }

    public BookDTO createBook(BookDTO bookDTO) {
        // Convert BookDTO to Book entity
        Book book = new Book(
                bookDTO.getId(),
                bookDTO.getTitle(),
                bookDTO.getAuthor(),
                bookDTO.getPublicationDate(),
                bookDTO.getPrice(),
                bookDTO.getIsbn()
        );

        // Save the book entity to the repository
        Book savedBook = bookRepository.save(book);

        // Convert saved book entity to BookDTO and return
        return new BookDTO(
                savedBook.getId(),
                savedBook.getTitle(),
                savedBook.getAuthor(),
                savedBook.getPublicationDate(),
                savedBook.getPrice(),
                savedBook.getIsbn()
        );
    }

    public void deleteBook(Integer id) {
        if (bookRepository.existsById(id)) {
            bookRepository.deleteById(id);
        } else {
            throw new ResourceNotFoundException("Book not found with id " + id);
        }
    }

    public void updateBook(Integer id, BookDTO bookDTO) {
        if (bookRepository.existsById(id)) {
            // Convert BookDTO to Book entity
            Book updatedBook = new Book(
                    id,
                    bookDTO.getTitle(),
                    bookDTO.getAuthor(),
                    bookDTO.getPublicationDate(),
                    bookDTO.getPrice(),
                    bookDTO.getIsbn()
            );

            // Save the updated book entity to the repository
            bookRepository.save(updatedBook);
        } else {
            throw new ResourceNotFoundException("Book not found with id " + id);
        }
    }

    public List<Book> getAllBooks() {
        return bookRepository.findAll();
    }

    public List<Book> getBooksByTitle(String title) {
        return bookRepository.findByTitleContainingIgnoreCase(title);
    }

    public List<Book> getBooksByAuthor(String author) {
        return bookRepository.findByAuthorContainingIgnoreCase(author);
    }

    public List<Book> getBooksByTitleAndAuthor(String title, String author) {
        return bookRepository.findByTitleContainingIgnoreCaseAndAuthorContainingIgnoreCase(title, author);
    }

    public Object getBookById(int i) {
        return null;
    }
}
