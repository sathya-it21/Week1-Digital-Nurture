package com.example.BookStoreAPI.assembler;

import com.example.BookStoreAPI.controller.BookController;
import com.example.BookStoreAPI.model.Book;
import com.example.BookStoreAPI.dto.BookDTO;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.Link;
import org.springframework.hateoas.server.mvc.WebMvcLinkBuilder;
import org.springframework.stereotype.Component;

@Component
public class BookResourceAssembler {

    public EntityModel<BookDTO> toModel(Book book) {
        BookDTO bookDTO = new BookDTO(
                book.getId(),
                book.getTitle(),
                book.getAuthor(),
                book.getPublicationDate(),
                book.getPrice(),
                book.getIsbn()
        );

        EntityModel<BookDTO> bookModel = EntityModel.of(bookDTO);

        // Link to self
        Link selfLink = WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(BookController.class).getBookById((long) book.getId())).withSelfRel();
        // Link to all books
        Link allBooksLink = WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(BookController.class).getAllBooks()).withRel("all-books");

        bookModel.add(selfLink);
        bookModel.add(allBooksLink);

        return bookModel;
    }
}
