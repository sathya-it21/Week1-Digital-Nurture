package com.example.BookStoreAPI.model;

import jakarta.persistence.*;
import lombok.Data;
import org.springframework.data.annotation.Version;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@Data
@Entity
@XmlRootElement
public class Customer {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    private String name;

    private String email;

    @XmlElement
    public String getName() {
        return name;
    }

    @XmlElement
    public int getId() {
        return id;
    }


    @XmlElement
    public String getEmail() {
        return email;
    }

    @XmlElement
    public String getPhoneNumber() {
        return phoneNumber;
    }

    @XmlElement
    public Integer getVersion() {
        return version;
    }

    @Column(name = "phone_number")
    private String phoneNumber;

    @Version
    private Integer version;

    // Constructors, getters, and setters
    public Customer() { }

    public Customer(int id, String name, String email, String phoneNumber) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.phoneNumber = phoneNumber;
    }
}
