package com.example.BookStoreAPI.controller;


import com.example.BookStoreAPI.model.Book;
import com.example.BookStoreAPI.service.BookService;
import com.fasterxml.jackson.databind.ObjectMapper;


import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultMatcher;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.testng.annotations.Test;

import java.util.List;
import java.util.Optional;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(BookController.class)
public class BookControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Mock
    private BookService bookService;

    @InjectMocks
    private BookController bookController;

    void setUp() {
        MockitoAnnotations.openMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(bookController).build();
    }

    @Test
    void testCreateBook() throws Exception {
        Book book = new Book(1, "Book Title", "Author", 19.99,"13432");
        String bookJson = new ObjectMapper().writeValueAsString(book);



        verify(bookService, times(1)).createBook(any(com.example.BookStoreAPI.dto.BookDTO.class));
    }

    @Test
    void testGetAllBooks() throws Exception {
        Book book1 = new Book(1, "Book 1", "Author 1", 15.99, "t48yfr");
        Book book2 = new Book(2, "Book 2", "Author 2", 20.99,"def3r454");
        when(bookService.getAllBooks()).thenReturn(List.of(book1, book2));

    }

    @Test
    void testGetBookById() throws Exception {
        Book book = new Book(1, "Book Title", "Author", 19.99,"13432");
        when(bookService.getBookById(1)).thenReturn(Optional.of(book));


    }

    @Test
    void testGetBookByIdNotFound() throws Exception {
        when(bookService.getBookById(1)).thenReturn(null);

        mockMvc.perform(MockMvcRequestBuilders.get("/books/1"))
                .andExpect(status().isNotFound());
    }
}
