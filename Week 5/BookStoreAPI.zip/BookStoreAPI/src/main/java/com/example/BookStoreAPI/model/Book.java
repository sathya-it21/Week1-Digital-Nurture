package com.example.BookStoreAPI.model;

import jakarta.persistence.*;
import jakarta.persistence.metamodel.SingularAttribute;
import lombok.Data;
import org.springframework.data.jpa.domain.AbstractPersistable;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;
import java.util.Date;

@Data

@Entity
@XmlRootElement

public class Book {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    private int id;

    private String title;
    private String author;

    @Temporal(TemporalType.DATE)
    private Date publicationDate;

    private double price;

    @Column(name = "isbn_number")
    private String isbn;

    @Version
    private Integer version;

    public Book(Integer id, String title, String author, Date publicationDate, double price, String isbn) {
        this.title = title;
        this.author = author;
        this.price = price;
        this.isbn = isbn;
    }

    public Book() {
    }

    public Book(String title, String author, Date publicationDate, double price, String isbn) {
        this.title = title;
        this.author = author;
        this.publicationDate = publicationDate;
        this.price = price;
        this.isbn = isbn;
    }

    public Book(int id, String title, String author, double price, String isbn) {
        this.id = id;
        this.title = title;
        this.author = author;
        this.price = price;
        this.isbn = isbn;
    }

    public Book(SingularAttribute<AbstractPersistable, Serializable> id, String title, String author, Date publicationDate, double price, String number) {

    }

    @XmlElement
    public int getId() {
        return id;
    }


    public void setId(int id) {
        this.id = id;
    }

    @XmlElement
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    @XmlElement
    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    @XmlElement
    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    @XmlElement
    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }


    @XmlElement
    public Date getPublicationDate() {
        return publicationDate;
    }

    public void setPublicationDate(Date publicationDate) {
        this.publicationDate = publicationDate;
    }
}
