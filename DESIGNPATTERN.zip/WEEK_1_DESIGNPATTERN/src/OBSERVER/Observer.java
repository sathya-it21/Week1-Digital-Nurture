package OBSERVER;

public interface Observer {
    void update(double stockPrice);
}
