package STRATEGYPATTERN;
public class Test {
public static void main(String[] args) {
    Payment_Context context = new Payment_Context();

    // Pay with Credit Card
    Payment creditCard = new Credit("1234-5678-9876-5432", "John Doe");
    context.setPaymentStrategy(creditCard);
    context.executePayment(100.0);

    // Pay with PayPal
    Payment payPal = new PayPal("johndoe@example.com");
    context.setPaymentStrategy(payPal);
    context.executePayment(200.0);
}
}
