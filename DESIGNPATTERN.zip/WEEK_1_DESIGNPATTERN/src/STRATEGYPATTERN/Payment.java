package STRATEGYPATTERN;


public interface Payment {
    void pay(double amount);
}