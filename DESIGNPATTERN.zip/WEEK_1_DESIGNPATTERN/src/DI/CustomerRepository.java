package DI;

public interface CustomerRepository {
	 Customer findCustomerById(String id);
}
