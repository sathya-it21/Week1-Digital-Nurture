package MVC;

public class Test {
    public static void main(String[] args) {
       
        Student model = new Student();
        model.setName("John Doe");
        model.setId("12345");
        model.setGrade("A");

       
        StudentView view = new StudentView();

        
        StudentController controller = new StudentController(model, view);

    
        controller.updateView();

        controller.setStudentName("Jane Smith");
        controller.setStudentGrade("B");

        
        controller.updateView();
    }
}
