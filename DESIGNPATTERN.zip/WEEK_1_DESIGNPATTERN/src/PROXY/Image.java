package PROXY;

public interface Image {
    void display();
}
