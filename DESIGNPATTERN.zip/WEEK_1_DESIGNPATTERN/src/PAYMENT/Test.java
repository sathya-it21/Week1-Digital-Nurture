package PAYMENT;

public class Test {
    public static void main(String[] args) {
        // Create instances of the payment gateways
        StripePaymentGateway stripeGateway = new StripePaymentGateway();
        PayPalPaymentGateway paypalGateway = new PayPalPaymentGateway();

        // Create adapters for each payment gateway
        PaymentProcessor stripeAdapter = new StripeAdapter(stripeGateway);
        PaymentProcessor paypalAdapter = new PayPalAdapter(paypalGateway);

        // Process payments using the adapters
        stripeAdapter.processPayment(100.00);
        paypalAdapter.processPayment(200.00);
    }
}