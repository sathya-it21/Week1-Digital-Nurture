package PAYMENT;

public class PayPalPaymentGateway {
    public void makePayment(double amount) {
        System.out.println("Making payment of $" + amount + " through PayPal.");
    }
}
