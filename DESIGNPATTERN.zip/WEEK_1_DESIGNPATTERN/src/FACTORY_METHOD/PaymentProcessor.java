package FACTORY_METHOD;

public interface PaymentProcessor {
	void processPayment(double amount);
}
