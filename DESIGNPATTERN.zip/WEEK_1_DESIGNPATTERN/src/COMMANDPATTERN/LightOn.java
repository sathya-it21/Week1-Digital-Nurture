package COMMANDPATTERN;

public class LightOn implements COMMAND {
    private Light light;

    public LightOn(Light light) {
        this.light = light;
    }

    @Override
    public void execute() {
        light.turnOn();
    }
}
