package COMMANDPATTERN;

public interface COMMAND {
    void execute();
}
