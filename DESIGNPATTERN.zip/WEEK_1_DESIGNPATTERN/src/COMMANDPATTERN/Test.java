package COMMANDPATTERN;

public class Test {
    public static void main(String[] args) {
        // Create receiver
        Light light = new Light();

        // Create concrete commands
        LightOn lightOn = new LightOn(light);
        LightOff lightOff = new LightOff(light);

        // Create invoker
        Remote remote = new Remote();

        // Turn the light on
        remote.setCommand(lightOn);
        remote.pressButton();

        // Turn the light off
        remote.setCommand(lightOff);
        remote.pressButton();
    }
}
