package COMMANDPATTERN;

public class Remote {
    private COMMAND command;

    public void setCommand(COMMAND command) {
        this.command = command;
    }

    public void pressButton() {
        command.execute();
    }
}
